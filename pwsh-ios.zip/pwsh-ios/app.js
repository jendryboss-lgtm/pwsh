(() => {
  "use strict";

  const VERSION = "7.6.6";
  const EDITION = "Core";
  const USER = "Jendry";
  const STORE_FS = "pwsh.fs.v1";
  const STORE_HIST = "pwsh.hist.v1";
  const STORE_VARS = "pwsh.vars.v1";
  const STORE_THEME = "pwsh.theme.v1";
  const STORE_CWD = "pwsh.cwd.v1";

  const $screen = document.getElementById("screen");
  const $prompt = document.getElementById("prompt");
  const $cmd = document.getElementById("cmdline");
  const $keys = document.getElementById("keys");
  const $install = document.getElementById("install");
  const $hostmeta = document.getElementById("hostmeta");

  const themes = ["classic", "cascade", "light"];
  let theme = localStorage.getItem(STORE_THEME) || "classic";
  document.documentElement.setAttribute("data-theme", theme);

  let ctrlOn = false;
  let history = JSON.parse(localStorage.getItem(STORE_HIST) || "[]");
  let histIdx = history.length;
  let draft = "";
  let running = false;
  let abortFlag = false;

  const aliases = {
    cls: "Clear-Host",
    clear: "Clear-Host",
    cd: "Set-Location",
    chdir: "Set-Location",
    sl: "Set-Location",
    ls: "Get-ChildItem",
    dir: "Get-ChildItem",
    gci: "Get-ChildItem",
    gi: "Get-Item",
    cat: "Get-Content",
    gc: "Get-Content",
    type: "Get-Content",
    rm: "Remove-Item",
    del: "Remove-Item",
    ri: "Remove-Item",
    cp: "Copy-Item",
    copy: "Copy-Item",
    mv: "Move-Item",
    move: "Move-Item",
    ren: "Rename-Item",
    ni: "New-Item",
    md: "New-Item",
    mkdir: "New-Item",
    echo: "Write-Output",
    write: "Write-Output",
    pwd: "Get-Location",
    gl: "Get-Location",
    h: "Get-History",
    history: "Get-History",
    man: "Get-Help",
    help: "Get-Help",
    gal: "Get-Alias",
    gcm: "Get-Command",
    gm: "Get-Member",
    ft: "Format-Table",
    fl: "Format-List",
    fw: "Format-Wide",
    select: "Select-Object",
    where: "Where-Object",
    "?": "Where-Object",
    "%": "ForEach-Object",
    foreach: "ForEach-Object",
    sort: "Sort-Object",
    group: "Group-Object",
    measure: "Measure-Object",
    sleep: "Start-Sleep",
    wget: "Invoke-WebRequest",
    curl: "Invoke-WebRequest",
    irm: "Invoke-RestMethod",
    iwr: "Invoke-WebRequest",
    iex: "Invoke-Expression",
    gv: "Get-Variable",
    sv: "Set-Variable",
    rv: "Remove-Variable",
    gps: "Get-Process",
    ps: "Get-Process",
    kill: "Stop-Process",
    guid: "New-Guid",
    whoami: "WhoAmI",
    pwsh: "Get-Host",
  };

  function defaultFs() {
    const file = (content, extra = {}) => ({
      type: "file",
      content: String(content ?? ""),
      length: String(content ?? "").length,
      lastWriteTime: new Date().toISOString(),
      mode: "-a----",
      ...extra,
    });
    const dir = (children = {}) => ({
      type: "dir",
      lastWriteTime: new Date().toISOString(),
      mode: "d-----",
      children,
    });
    return dir({
      Users: dir({
        [USER]: dir({
          Documents: dir({
            "profile.ps1": file(`# PowerShell profile for iPhone\nWrite-Host "Profile loaded." -ForegroundColor Cyan\n`),
            "notes.txt": file("Welcome to PowerShell on iPhone.\nType Get-Help to start.\n"),
          }),
          Desktop: dir({}),
          Downloads: dir({}),
          ".config": dir({
            powershell: dir({
              "Microsoft.PowerShell_profile.ps1": file("# $PROFILE\n"),
            }),
          }),
        }),
      }),
      tmp: dir({}),
      bin: dir({
        pwsh: file("pwsh-ios host"),
      }),
    });
  }

  let fsRoot = null;
  try {
    fsRoot = JSON.parse(localStorage.getItem(STORE_FS));
    if (!fsRoot || fsRoot.type !== "dir") fsRoot = defaultFs();
  } catch {
    fsRoot = defaultFs();
  }

  let cwd = localStorage.getItem(STORE_CWD) || `/Users/${USER}`;
  const locationStack = [];

  const vars = {
    HOME: `/Users/${USER}`,
    PWD: cwd,
    USER,
    USERNAME: USER,
    HOSTNAME: "iPhone",
    PSVersionTable: null,
    PROFILE: `/Users/${USER}/.config/powershell/Microsoft.PowerShell_profile.ps1`,
    ErrorActionPreference: "Continue",
    VerbosePreference: "SilentlyContinue",
    DebugPreference: "SilentlyContinue",
    InformationPreference: "Continue",
    ProgressPreference: "Continue",
    MaximumHistoryCount: 4096,
    PSEdition: EDITION,
    true: true,
    false: false,
    null: null,
    Host: { Name: "ConsoleHost", Version: VERSION, UI: { RawUI: { WindowTitle: "PowerShell 7.6" } } },
    PID: 7,
    IsLinux: false,
    IsMacOS: false,
    IsWindows: false,
    IsCoreCLR: true,
    PSCulture: navigator.language || "en-US",
    PSUICulture: navigator.language || "en-US",
  };

  try {
    const saved = JSON.parse(localStorage.getItem(STORE_VARS) || "{}");
    Object.assign(vars, saved);
  } catch {}

  vars.PSVersionTable = {
    PSVersion: VERSION,
    PSEdition: EDITION,
    GitCommitId: VERSION,
    OS: `${navigator.platform || "iOS"} (${navigator.userAgent.includes("iPhone") ? "iPhone" : navigator.userAgent.includes("iPad") ? "iPad" : "Web"})`,
    Platform: "Unix",
    PSCompatibleVersions: ["1.0", "2.0", "3.0", "4.0", "5.0", "5.1", "6.0", "7.0", "7.6"],
    PSRemotingProtocolVersion: "2.3",
    SerializationVersion: "1.1.0.1",
    WSManStackVersion: "3.0",
    Engine: "pwsh-ios",
    Note: "Microsoft does not ship official pwsh for iOS. This is a PowerShell-compatible host.",
  };

  const functions = {};
  const cmdlets = {};
  const help = {};

  function persist() {
    try {
      localStorage.setItem(STORE_FS, JSON.stringify(fsRoot));
      localStorage.setItem(STORE_HIST, JSON.stringify(history.slice(-400)));
      localStorage.setItem(STORE_CWD, cwd);
      const keep = { ...vars };
      delete keep.PSVersionTable;
      delete keep.Host;
      localStorage.setItem(STORE_VARS, JSON.stringify(keep));
    } catch {}
  }

  function normPath(p) {
    if (p == null || p === "") return cwd;
    p = String(p).replace(/\\/g, "/");
    if (p === "~" || p.startsWith("~/")) p = vars.HOME + p.slice(1);
    if (p.match(/^[A-Za-z]:/)) p = p.slice(2);
    if (!p.startsWith("/")) {
      p = (cwd.replace(/\/$/, "") + "/" + p).replace(/\/+/g, "/");
    }
    const parts = [];
    for (const seg of p.split("/")) {
      if (!seg || seg === ".") continue;
      if (seg === "..") parts.pop();
      else parts.push(seg);
    }
    return "/" + parts.join("/");
  }

  function displayPath(p) {
    return (p || "/").replace(/\//g, "\\");
  }

  function walk(path, createDirs = false) {
    const full = normPath(path);
    const parts = full.split("/").filter(Boolean);
    let node = fsRoot;
    let parent = null;
    let name = "";
    for (const part of parts) {
      if (!node || node.type !== "dir") return { full, node: null, parent, name: part };
      if (!node.children[part]) {
        if (!createDirs) return { full, node: null, parent: node, name: part };
        node.children[part] = {
          type: "dir",
          lastWriteTime: new Date().toISOString(),
          mode: "d-----",
          children: {},
        };
      }
      parent = node;
      name = part;
      node = node.children[part];
    }
    return { full, node: node || fsRoot, parent, name };
  }

  function listDir(node) {
    if (!node || node.type !== "dir") return [];
    return Object.entries(node.children).map(([Name, item]) => ({
      Mode: item.mode || (item.type === "dir" ? "d-----" : "-a----"),
      LastWriteTime: new Date(item.lastWriteTime || Date.now()),
      Length: item.type === "file" ? (item.content || "").length : null,
      Name,
      PSIsContainer: item.type === "dir",
      FullName: null,
    }));
  }

  function setCwd(path) {
    const { full, node } = walk(path);
    if (!node || node.type !== "dir") throw err(`Cannot find path '${path}' because it does not exist.`);
    cwd = full === "" ? "/" : full;
    vars.PWD = cwd;
    refreshPrompt();
    persist();
  }

  function refreshPrompt() {
    $prompt.textContent = `PS ${displayPath(cwd)}>`;
  }

  function err(msg) {
    const e = new Error(msg);
    e.ps = true;
    return e;
  }

  function register(name, aliasesList, synopsis, fn) {
    const spec = { name, aliases: aliasesList || [], synopsis, fn };
    cmdlets[name.toLowerCase()] = spec;
    help[name.toLowerCase()] = { name, synopsis, aliases: aliasesList || [] };
    for (const a of aliasesList || []) aliases[a.toLowerCase()] = name;
  }

  function resolveCommand(name) {
    if (!name) return null;
    const raw = name.replace(/^\\/, "");
    const key = raw.toLowerCase();
    if (functions[key]) return { type: "function", name: raw, fn: functions[key] };
    if (aliases[key]) return resolveCommand(aliases[key]);
    if (cmdlets[key]) return { type: "cmdlet", name: cmdlets[key].name, spec: cmdlets[key] };
    return null;
  }

  function tokenize(input) {
    const tokens = [];
    let i = 0;
    const s = input;
    const peek = () => s[i];
    while (i < s.length) {
      const c = peek();
      if (c === " " || c === "\t") {
        i++;
        continue;
      }
      if (c === "#") break;
      if (c === "|") {
        tokens.push({ t: "pipe" });
        i++;
        continue;
      }
      if (c === ";") {
        tokens.push({ t: "semi" });
        i++;
        continue;
      }
      if (c === "'" ) {
        i++;
        let out = "";
        while (i < s.length && s[i] !== "'") {
          out += s[i++];
        }
        if (s[i] === "'") i++;
        tokens.push({ t: "str", v: out });
        continue;
      }
      if (c === '"') {
        i++;
        let out = "";
        while (i < s.length && s[i] !== '"') {
          if (s[i] === "`" && i + 1 < s.length) {
            out += s[i + 1];
            i += 2;
          } else {
            out += s[i++];
          }
        }
        if (s[i] === '"') i++;
        tokens.push({ t: "dstr", v: out });
        continue;
      }
      let out = "";
      while (i < s.length && !/\s|[|;]/.test(s[i])) {
        if (s[i] === "`" && i + 1 < s.length) {
          out += s[i + 1];
          i += 2;
        } else out += s[i++];
      }
      tokens.push({ t: "word", v: out });
    }
    return tokens;
  }

  function expandValue(v, pipeline) {
    if (v == null) return v;
    if (typeof v !== "string") return v;
    if (v === "$_") return pipeline;
    if (v.startsWith("$_.")) {
      return getProp(pipeline, v.slice(3));
    }
    return v.replace(/\$([A-Za-z_][A-Za-z0-9_]*)|\$\{([^}]+)\}/g, (_, a, b) => {
      const name = a || b;
      if (Object.prototype.hasOwnProperty.call(vars, name)) {
        const val = vars[name];
        if (val == null) return "";
        if (typeof val === "object") return JSON.stringify(val);
        return String(val);
      }
      return "";
    });
  }

  function getProp(obj, path) {
    if (obj == null) return undefined;
    const parts = path.split(".");
    let cur = obj;
    for (const p of parts) {
      if (cur == null) return undefined;
      cur = cur[p] ?? cur[p.toLowerCase?.()] ?? cur[capitalize(p)];
    }
    return cur;
  }

  function capitalize(s) {
    return s ? s[0].toUpperCase() + s.slice(1) : s;
  }

  function parseArgs(tokens, pipeline) {
    const positional = [];
    const named = {};
    for (let i = 0; i < tokens.length; i++) {
      const tok = tokens[i];
      let v = tok.v;
      if (tok.t === "dstr") v = expandValue(v, pipeline);
      if (tok.t === "word") {
        if (v.startsWith("-") && v.length > 1 && !/^-\d/.test(v)) {
          const rawName = v.replace(/^-+/, "");
          if (rawName.includes(":")) {
            const [n, rest] = rawName.split(/:(.*)/);
            named[n.toLowerCase()] = rest === "" ? true : expandValue(rest, pipeline);
            continue;
          }
          const next = tokens[i + 1];
          if (!next || (next.t === "word" && next.v.startsWith("-"))) {
            named[rawName.toLowerCase()] = true;
          } else {
            let nv = next.v;
            if (next.t === "dstr" || next.t === "word") nv = expandValue(nv, pipeline);
            named[rawName.toLowerCase()] = nv;
            i++;
          }
          continue;
        }
        v = expandValue(v, pipeline);
      }
      positional.push(v);
    }
    return { positional, named };
  }

  function param(named, names, fallback) {
    for (const n of names) {
      const k = n.toLowerCase();
      if (Object.prototype.hasOwnProperty.call(named, k)) return named[k];
      for (const key of Object.keys(named)) {
        if (k.startsWith(key) || key.startsWith(k)) return named[key];
      }
    }
    return fallback;
  }

  function flag(named, names) {
    const v = param(named, names, false);
    return v === true || v === "true" || v === "";
  }

  function splitStatements(tokens) {
    const stmts = [];
    let cur = [];
    for (const t of tokens) {
      if (t.t === "semi") {
        if (cur.length) stmts.push(cur);
        cur = [];
      } else cur.push(t);
    }
    if (cur.length) stmts.push(cur);
    return stmts;
  }

  function splitPipeline(tokens) {
    const stages = [];
    let cur = [];
    for (const t of tokens) {
      if (t.t === "pipe") {
        stages.push(cur);
        cur = [];
      } else cur.push(t);
    }
    stages.push(cur);
    return stages;
  }

  function toArray(x) {
    if (x == null) return [];
    if (Array.isArray(x)) return x;
    return [x];
  }

  function unwrap(x) {
    if (Array.isArray(x) && x.length === 1) return x[0];
    return x;
  }

  async function invokeCommand(name, argTokens, pipeline, ctx) {
    if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) && argTokens.length && argTokens[0].v === "=") {
      const rhs = argTokens.slice(1).map((t) => t.v).join(" ");
      vars[name] = coerce(expandValue(rhs, pipeline));
      persist();
      return;
    }
    if (name.startsWith("$") && argTokens[0] && (argTokens[0].v === "=" || name.includes("="))) {
      let n = name.slice(1);
      let rest = argTokens;
      if (name.includes("=")) {
        const [left, right] = name.split(/=(.*)/);
        n = left.slice(1);
        rest = [{ t: "word", v: right }, ...argTokens];
      } else rest = argTokens.slice(1);
      vars[n] = coerce(expandValue(rest.map((t) => t.v).join(" "), pipeline));
      persist();
      return;
    }
    if (name.startsWith("$") && argTokens.length === 0) {
      const n = name.slice(1);
      return Object.prototype.hasOwnProperty.call(vars, n) ? vars[n] : undefined;
    }

    const resolved = resolveCommand(name);
    if (!resolved) {
      throw err(`The term '${name}' is not recognized as a name of a cmdlet, function, script file, or executable program.`);
    }
    const { positional, named } = parseArgs(argTokens, pipeline);
    if (resolved.type === "function") {
      return resolved.fn({ positional, named, pipeline, ctx });
    }
    return resolved.spec.fn({ positional, named, pipeline, ctx, rawName: name });
  }

  function coerce(v) {
    if (v === "true") return true;
    if (v === "false") return false;
    if (v === "$true") return true;
    if (v === "$false") return false;
    if (v === "$null" || v === "null") return null;
    if (v !== "" && !Number.isNaN(Number(v)) && /^-?\d+(\.\d+)?$/.test(String(v))) return Number(v);
    return v;
  }

  async function runPipeline(tokens, ctx) {
    const stages = splitPipeline(tokens);
    let data = undefined;
    let first = true;
    for (const stage of stages) {
      if (!stage.length) continue;
      const nameTok = stage[0];
      const name = nameTok.v;
      const args = stage.slice(1);
      if (first && name && name.includes("=") && name.startsWith("$")) {
        data = await invokeCommand(name, args, data, ctx);
      } else {
        data = await invokeCommand(name, args, first ? undefined : data, ctx);
      }
      first = false;
      if (abortFlag) break;
    }
    return data;
  }

  async function runScript(text, ctx = {}) {
    const tokens = tokenize(text);
    const stmts = splitStatements(tokens);
    let last;
    for (const stmt of stmts) {
      if (!stmt.length) continue;
      if (stmt[0].v && stmt[0].v.toLowerCase() === "function") {
        defineFunction(stmt);
        continue;
      }
      last = await runPipeline(stmt, ctx);
    }
    return last;
  }

  function defineFunction(tokens) {
    const name = tokens[1] && tokens[1].v;
    if (!name) throw err("Missing function name.");
    const body = tokens.slice(2).map((t) => t.v).join(" ");
    functions[name.toLowerCase()] = async ({ pipeline }) => {
      const prev = vars._;
      vars._ = pipeline;
      try {
        return await runScript(body.replace(/^\{|\}$/g, ""), {});
      } finally {
        vars._ = prev;
      }
    };
    print(`function ${name} defined`, "dim");
  }

  function print(text, cls) {
    if (text == null || text === "") return;
    const div = document.createElement("div");
    div.className = "line" + (cls ? " " + cls : "");
    div.textContent = String(text);
    $screen.appendChild(div);
    $screen.scrollTop = $screen.scrollHeight;
  }

  function printHTML(html) {
    const div = document.createElement("div");
    div.className = "line";
    div.innerHTML = html;
    $screen.appendChild(div);
    $screen.scrollTop = $screen.scrollHeight;
  }

  function writePromptEcho(line) {
    const div = document.createElement("div");
    div.className = "line";
    const p = document.createElement("span");
    p.className = "accent";
    p.textContent = `PS ${displayPath(cwd)}> `;
    const c = document.createElement("span");
    c.textContent = line;
    div.appendChild(p);
    div.appendChild(c);
    $screen.appendChild(div);
  }

  function formatValue(value, style) {
    if (value == null) return;
    if (value && value.__silent) return;
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      print(String(value));
      return;
    }
    const arr = toArray(value);
    if (!arr.length) return;
    if (arr.every((x) => x == null || typeof x !== "object")) {
      arr.forEach((x) => print(String(x)));
      return;
    }
    if (style === "list") {
      arr.forEach((obj, i) => {
        if (i) print("");
        const keys = Object.keys(obj || {});
        const w = Math.max(...keys.map((k) => k.length), 1);
        keys.forEach((k) => print(`${k.padEnd(w)} : ${stringify(obj[k])}`));
      });
      return;
    }
    const keys = [];
    const seen = new Set();
    for (const obj of arr) {
      if (obj && typeof obj === "object") {
        for (const k of Object.keys(obj)) {
          if (!seen.has(k) && k !== "PSIsContainer") {
            seen.add(k);
            keys.push(k);
          }
        }
      }
    }
    const show = keys.slice(0, 6);
    if (!show.length) {
      arr.forEach((x) => print(stringify(x)));
      return;
    }
    const esc = (s) =>
      String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    let html = '<table class="ft"><thead><tr>' + show.map((k) => `<th>${esc(k)}</th>`).join("") + "</tr></thead><tbody>";
    for (const obj of arr) {
      html += "<tr>" + show.map((k) => `<td>${esc(formatCell(obj?.[k]))}</td>`).join("") + "</tr>";
    }
    html += "</tbody></table>";
    printHTML(html);
  }

  function formatCell(v) {
    if (v == null) return "";
    if (v instanceof Date) {
      return v.toLocaleString();
    }
    if (typeof v === "object") return Array.isArray(v) ? v.join(",") : JSON.stringify(v);
    return String(v);
  }

  function stringify(v) {
    if (v == null) return "";
    if (typeof v === "object") {
      try {
        return JSON.stringify(v);
      } catch {
        return String(v);
      }
    }
    return String(v);
  }

  /* ---------------- cmdlets ---------------- */

  register("Get-Help", ["help", "man"], "Displays help about cmdlets and the host.", ({ positional, named }) => {
    const topic = String(positional[0] || param(named, ["name"], "") || "").toLowerCase();
    if (!topic || topic === "about_pwsh" || topic === "pwsh") {
      return [
        "TOPIC",
        "    PowerShell 7.6-compatible host for iPhone",
        "",
        "SYNOPSIS",
        "    Microsoft does not publish pwsh for iOS. This app is a local PowerShell-compatible",
        "    engine with filesystem, pipelines, aliases, variables, web cmdlets, and formatting.",
        "",
        "    For a real Microsoft PowerShell 7.6 process, install pwsh on a Mac/Windows/Linux",
        "    box (see https://learn.microsoft.com/powershell/) and SSH in with Termius, Blink,",
        "    or Prompt. Then run:  pwsh",
        "",
        "COMMON COMMANDS",
        "    Get-Command            List cmdlets",
        "    Get-ChildItem          List files (ls, dir)",
        "    Set-Location           Change directory (cd)",
        "    Get-Content            Read a file (cat)",
        "    Invoke-RestMethod      Call a JSON API (irm)",
        "    ConvertTo-Json         Serialize objects",
        "    Get-Alias              Show aliases",
        "    Set-Theme Cascade      Switch color theme",
        "    Connect-PSSession      How to attach to real pwsh",
        "",
        "EXAMPLES",
        "    Get-ChildItem /Users/Jendry",
        '    "hello" | ForEach-Object { $_.ToUpper() }',
        "    1..5 | Measure-Object -Sum",
        "    Invoke-RestMethod https://httpbin.org/json",
      ].join("\n");
    }
    const resolved = resolveCommand(topic);
    const key = (resolved && resolved.name ? resolved.name : topic).toLowerCase();
    const h = help[key];
    if (!h) return `Get-Help: No help found for '${topic}'.`;
    return [
      `NAME`,
      `    ${h.name}`,
      "",
      "SYNOPSIS",
      `    ${h.synopsis}`,
      "",
      "ALIASES",
      `    ${(h.aliases || []).join(", ") || "(none)"}`,
    ].join("\n");
  });

  register("Get-Command", ["gcm"], "Gets all commands that are installed on the computer.", ({ positional, named }) => {
    const noun = param(named, ["noun"]);
    const verb = param(named, ["verb"]);
    const name = String(positional[0] || param(named, ["name"], "") || "").toLowerCase();
    const rows = Object.values(cmdlets)
      .filter((c) => {
        if (name && !c.name.toLowerCase().includes(name.replace("*", ""))) return false;
        if (verb && !c.name.toLowerCase().startsWith(String(verb).toLowerCase() + "-")) return false;
        if (noun && !c.name.toLowerCase().endsWith("-" + String(noun).toLowerCase())) return false;
        return true;
      })
      .map((c) => ({
        CommandType: "Cmdlet",
        Name: c.name,
        Version: VERSION,
        Source: "Microsoft.PowerShell.Core",
      }));
    Object.keys(functions).forEach((n) => {
      rows.push({ CommandType: "Function", Name: n, Version: VERSION, Source: "" });
    });
    return rows.sort((a, b) => a.Name.localeCompare(b.Name));
  });

  register("Get-Alias", ["gal"], "Gets the aliases for the current session.", ({ positional, named }) => {
    const name = String(positional[0] || param(named, ["name"], "") || "").toLowerCase();
    return Object.entries(aliases)
      .filter(([a]) => !name || a.includes(name.replace("*", "")))
      .map(([Name, Definition]) => ({ CommandType: "Alias", Name, Definition }))
      .sort((a, b) => a.Name.localeCompare(b.Name));
  });

  register("Set-Alias", ["sal"], "Creates or changes an alias.", ({ positional, named }) => {
    const name = positional[0] || param(named, ["name"]);
    const value = positional[1] || param(named, ["value", "definition"]);
    if (!name || !value) throw err("Specify -Name and -Value.");
    aliases[String(name).toLowerCase()] = String(value);
    return;
  });

  register("Get-History", ["h", "history"], "Gets a list of the commands entered during the current session.", () =>
    history.map((CommandLine, i) => ({ Id: i + 1, CommandLine }))
  );

  register("Clear-History", [], "Deletes entries from the command history.", () => {
    history = [];
    histIdx = 0;
    persist();
  });

  register("Invoke-History", ["r"], "Runs commands from the session history.", ({ positional }) => {
    const id = Number(positional[0] || history.length);
    const line = history[id - 1];
    if (!line) throw err("Cannot find history id.");
    return runScript(line);
  });

  register("Clear-Host", ["cls", "clear"], "Clears the host display.", () => {
    $screen.innerHTML = "";
    return { __silent: true };
  });

  register("Get-Host", [], "Gets an object that represents the current host program.", () => ({
    Name: "ConsoleHost",
    Version: VERSION,
    InstanceId: "pwsh-ios",
    UI: "System.Management.Automation.Internal.Host.InternalHostUserInterface",
    CurrentCulture: navigator.language,
    CurrentUICulture: navigator.language,
    PrivateData: { ErrorForegroundColor: "Red", WarningForegroundColor: "Yellow" },
  }));

  register("Get-Date", [], "Gets the current date and time.", ({ named }) => {
    const d = new Date();
    const fmt = param(named, ["format", "uformat"]);
    if (fmt) return formatDate(d, String(fmt));
    return d.toString();
  });

  function formatDate(d, fmt) {
    const pad = (n) => String(n).padStart(2, "0");
    return fmt
      .replace(/yyyy/g, d.getFullYear())
      .replace(/MM/g, pad(d.getMonth() + 1))
      .replace(/dd/g, pad(d.getDate()))
      .replace(/HH/g, pad(d.getHours()))
      .replace(/mm/g, pad(d.getMinutes()))
      .replace(/ss/g, pad(d.getSeconds()));
  }

  register("Get-Random", [], "Gets a random number.", ({ positional, named, pipeline }) => {
    const items = pipeline != null ? toArray(pipeline) : null;
    if (items && items.length) return items[Math.floor(Math.random() * items.length)];
    const max = Number(positional[0] ?? param(named, ["maximum"], 2147483647));
    const min = Number(param(named, ["minimum"], 0));
    return Math.floor(Math.random() * (max - min)) + min;
  });

  register("New-Guid", ["guid"], "Creates a GUID.", () =>
    crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
    })
  );

  register("New-TimeSpan", [], "Creates a TimeSpan object.", ({ named }) => {
    const days = Number(param(named, ["days"], 0));
    const hours = Number(param(named, ["hours"], 0));
    const minutes = Number(param(named, ["minutes"], 0));
    const seconds = Number(param(named, ["seconds"], 0));
    const total = ((days * 24 + hours) * 60 + minutes) * 60 + seconds;
    return { Days: days, Hours: hours, Minutes: minutes, Seconds: seconds, TotalSeconds: total };
  });

  register("Start-Sleep", ["sleep"], "Suspends the activity in a script or session for the specified period of time.", async ({ positional, named }) => {
    let ms = Number(param(named, ["milliseconds"], NaN));
    if (Number.isNaN(ms)) ms = Number(positional[0] ?? param(named, ["seconds"], 0)) * 1000;
    const step = 50;
    let waited = 0;
    while (waited < ms) {
      if (abortFlag) break;
      await new Promise((r) => setTimeout(r, Math.min(step, ms - waited)));
      waited += step;
    }
  });

  register("Write-Output", ["echo", "write"], "Sends the specified objects to the next command in the pipeline.", ({ positional, pipeline }) => {
    const items = positional.length ? positional : toArray(pipeline);
    return unwrap(items.map(coerce));
  });

  register("Write-Host", [], "Writes customized output to a host.", ({ positional, named }) => {
    const msg = positional.join(" ");
    const color = String(param(named, ["foregroundcolor"], "")).toLowerCase();
    const cls = color.includes("red") ? "err" : color.includes("yellow") ? "warn" : color.includes("green") ? "ok" : color ? "accent" : "";
    print(msg, cls);
    return { __silent: true };
  });

  register("Write-Error", [], "Writes an object to the error stream.", ({ positional }) => {
    print(positional.join(" "), "err");
    return { __silent: true };
  });

  register("Write-Warning", [], "Writes a warning message.", ({ positional }) => {
    print(`WARNING: ${positional.join(" ")}`, "warn");
    return { __silent: true };
  });

  register("Write-Verbose", [], "Writes text to the verbose message stream.", ({ positional }) => {
    if (String(vars.VerbosePreference).toLowerCase() === "continue") print(`VERBOSE: ${positional.join(" ")}`, "dim");
    return { __silent: true };
  });

  register("Out-Null", [], "Hides output.", () => ({ __silent: true }));
  register("Out-String", [], "Outputs objects as strings.", ({ pipeline }) =>
    toArray(pipeline)
      .map((x) => (typeof x === "object" ? JSON.stringify(x, null, 2) : String(x)))
      .join("\n")
  );
  register("Out-Host", [], "Sends output to the host.", ({ pipeline }) => {
    formatValue(pipeline);
    return { __silent: true };
  });

  register("Out-File", [], "Sends output to a file.", ({ positional, named, pipeline }) => {
    const path = positional[0] || param(named, ["filepath", "file"]);
    if (!path) throw err("A file path is required.");
    const { parent, name } = ensureParent(path);
    const text = toArray(pipeline)
      .map((x) => (typeof x === "object" ? JSON.stringify(x, null, 2) : String(x ?? "")))
      .join("\n");
    parent.children[name] = {
      type: "file",
      content: flag(named, ["append"]) && parent.children[name]?.content ? parent.children[name].content + "\n" + text : text,
      lastWriteTime: new Date().toISOString(),
      mode: "-a----",
    };
    persist();
  });

  register("Set-Location", ["cd", "chdir", "sl"], "Sets the current working location.", ({ positional, named }) => {
    const path = positional[0] ?? param(named, ["path"], vars.HOME);
    setCwd(path);
  });

  register("Get-Location", ["pwd", "gl"], "Gets information about the current working location.", () => ({
    Drive: "iOS",
    Provider: "FileSystem",
    Path: cwd,
    ProviderPath: cwd,
  }));

  register("Push-Location", ["pushd"], "Adds the current location to the top of a location stack.", ({ positional }) => {
    locationStack.push(cwd);
    if (positional[0]) setCwd(positional[0]);
  });

  register("Pop-Location", ["popd"], "Changes the current location to the location most recently pushed.", () => {
    const last = locationStack.pop();
    if (last) setCwd(last);
  });

  register("Get-ChildItem", ["ls", "dir", "gci"], "Gets the items and child items in one or more specified locations.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"], cwd);
    const force = flag(named, ["force"]);
    const rec = flag(named, ["recurse", "r"]);
    const { node, full } = walk(path);
    if (!node) throw err(`Cannot find path '${path}' because it does not exist.`);
    if (node.type === "file") {
      return [{ Mode: node.mode, LastWriteTime: new Date(node.lastWriteTime), Length: (node.content || "").length, Name: full.split("/").pop() }];
    }
    const out = [];
    const walkRec = (n, prefix) => {
      for (const row of listDir(n)) {
        if (!force && row.Name.startsWith(".")) continue;
        row.FullName = (prefix + "/" + row.Name).replace(/\/+/g, "/");
        out.push(row);
        if (rec && row.PSIsContainer) walkRec(n.children[row.Name], row.FullName);
      }
    };
    walkRec(node, full);
    return out;
  });

  register("Get-Item", ["gi"], "Gets the item at the specified location.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"], cwd);
    const { node, full } = walk(path);
    if (!node) throw err(`Cannot find path '${path}'.`);
    return {
      Mode: node.mode || (node.type === "dir" ? "d-----" : "-a----"),
      LastWriteTime: new Date(node.lastWriteTime || Date.now()),
      Length: node.type === "file" ? (node.content || "").length : null,
      Name: full.split("/").pop() || "/",
      FullName: full,
      PSIsContainer: node.type === "dir",
    };
  });

  register("Test-Path", [], "Determines whether all elements of a path exist.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    if (!path) return false;
    return !!walk(path).node;
  });

  register("Join-Path", [], "Combines a path and a child path.", ({ positional, named }) => {
    const a = positional[0] || param(named, ["path"]);
    const b = positional[1] || param(named, ["childpath"]);
    return normPath(String(a).replace(/\/$/, "") + "/" + String(b || "").replace(/^\//, ""));
  });

  register("Split-Path", [], "Returns the specified part of a path.", ({ positional, named }) => {
    const p = normPath(positional[0] || param(named, ["path"]));
    if (flag(named, ["leaf"])) return p.split("/").pop();
    if (flag(named, ["qualifier"])) return "iOS:";
    const parts = p.split("/");
    parts.pop();
    return parts.join("/") || "/";
  });

  register("Resolve-Path", [], "Resolves the wildcard characters in a path.", ({ positional, named }) => {
    const p = positional[0] || param(named, ["path"]);
    const { full, node } = walk(p);
    if (!node) throw err(`Cannot find path '${p}'.`);
    return { Path: full, Provider: "FileSystem" };
  });

  function ensureParent(path) {
    const full = normPath(path);
    const parts = full.split("/").filter(Boolean);
    const name = parts.pop();
    const parentPath = "/" + parts.join("/");
    const { node: parent } = walk(parentPath, true);
    if (!parent || parent.type !== "dir") throw err(`Cannot find parent of '${path}'.`);
    return { parent, name, full };
  }

  register("New-Item", ["ni", "md", "mkdir"], "Creates a new item.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    if (!path) throw err("A path is required.");
    let itemType = String(param(named, ["itemtype", "type"], "")).toLowerCase();
    const value = param(named, ["value"]);
    if (!itemType) {
      itemType = (aliases.md && (positional.name === undefined) && !value) ? "directory" : value != null ? "file" : "directory";
    }
    const { parent, name, full } = ensureParent(path);
    if (itemType.startsWith("dir")) {
      parent.children[name] = { type: "dir", children: {}, lastWriteTime: new Date().toISOString(), mode: "d-----" };
    } else {
      parent.children[name] = {
        type: "file",
        content: value != null ? String(value) : "",
        lastWriteTime: new Date().toISOString(),
        mode: "-a----",
      };
    }
    persist();
    return { FullName: full, PSIsContainer: itemType.startsWith("dir") };
  });

  register("Remove-Item", ["rm", "del", "ri", "erase"], "Deletes the specified items.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    const rec = flag(named, ["recurse", "r", "force"]);
    const { parent, name, node } = walk(path);
    if (!node || !parent) throw err(`Cannot find path '${path}'.`);
    if (node.type === "dir" && Object.keys(node.children || {}).length && !rec) {
      throw err(`The item at '${path}' has children and the Recurse parameter was not specified.`);
    }
    delete parent.children[name];
    persist();
  });

  register("Copy-Item", ["cp", "copy", "cpi"], "Copies an item from one location to another.", ({ positional, named }) => {
    const src = positional[0] || param(named, ["path"]);
    const dest = positional[1] || param(named, ["destination"]);
    const { node } = walk(src);
    if (!node) throw err(`Cannot find path '${src}'.`);
    const cloned = JSON.parse(JSON.stringify(node));
    const destWalk = walk(dest);
    if (destWalk.node && destWalk.node.type === "dir") {
      destWalk.node.children[src.split("/").pop().split("\\").pop()] = cloned;
    } else {
      const { parent, name } = ensureParent(dest);
      parent.children[name] = cloned;
    }
    persist();
  });

  register("Move-Item", ["mv", "move", "mi"], "Moves an item from one location to another.", ({ positional, named }) => {
    const src = positional[0] || param(named, ["path"]);
    const dest = positional[1] || param(named, ["destination"]);
    const { node, parent, name } = walk(src);
    if (!node || !parent) throw err(`Cannot find path '${src}'.`);
    const cloned = JSON.parse(JSON.stringify(node));
    const destWalk = walk(dest);
    if (destWalk.node && destWalk.node.type === "dir") {
      destWalk.node.children[name] = cloned;
    } else {
      const d = ensureParent(dest);
      d.parent.children[d.name] = cloned;
    }
    delete parent.children[name];
    persist();
  });

  register("Rename-Item", ["ren", "rni"], "Renames an item.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    const newName = positional[1] || param(named, ["newname"]);
    const { node, parent, name } = walk(path);
    if (!node || !parent) throw err(`Cannot find path '${path}'.`);
    parent.children[String(newName)] = node;
    delete parent.children[name];
    persist();
  });

  register("Get-Content", ["cat", "gc", "type"], "Gets the content of the item at the specified location.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    const { node } = walk(path);
    if (!node) throw err(`Cannot find path '${path}'.`);
    if (node.type === "dir") throw err("The item is a directory.");
    const raw = node.content || "";
    const rawLines = raw.split(/\r?\n/);
    const tail = param(named, ["tail"]);
    if (tail != null) return rawLines.slice(-Number(tail)).join("\n");
    const total = param(named, ["totalcount", "head"]);
    if (total != null) return rawLines.slice(0, Number(total)).join("\n");
    return raw;
  });

  register("Set-Content", ["sc"], "Writes or replaces the content in an item.", ({ positional, named, pipeline }) => {
    const path = positional[0] || param(named, ["path"]);
    const value = positional.slice(1).join(" ") || param(named, ["value"]) || (pipeline != null ? stringify(pipeline) : "");
    const { parent, name } = ensureParent(path);
    parent.children[name] = { type: "file", content: String(value), lastWriteTime: new Date().toISOString(), mode: "-a----" };
    persist();
  });

  register("Add-Content", ["ac"], "Appends content to the specified items.", ({ positional, named, pipeline }) => {
    const path = positional[0] || param(named, ["path"]);
    const value = positional.slice(1).join(" ") || param(named, ["value"]) || stringify(pipeline);
    const { parent, name, node } = (() => {
      const w = walk(path);
      if (w.node && w.parent) return w;
      return { ...ensureParent(path), node: null };
    })();
    const prev = node && node.type === "file" ? node.content : "";
    parent.children[name] = {
      type: "file",
      content: prev ? prev + "\n" + value : String(value),
      lastWriteTime: new Date().toISOString(),
      mode: "-a----",
    };
    persist();
  });

  register("Select-Object", ["select"], "Selects objects or object properties.", ({ positional, named, pipeline }) => {
    const first = param(named, ["first"]);
    const last = param(named, ["last"]);
    const skip = Number(param(named, ["skip"], 0));
    let items = toArray(pipeline).slice(skip);
    if (first != null) items = items.slice(0, Number(first));
    if (last != null) items = items.slice(-Number(last));
    const props = [];
    if (named.property) props.push(...String(named.property).split(","));
    positional.forEach((p) => String(p).split(",").forEach((x) => props.push(x.trim())));
    const clean = props.map((p) => p.replace(/^[-]/, "")).filter((p) => !["first", "last", "skip", "property"].includes(p.toLowerCase()));
    if (!clean.length) return unwrap(items);
    return items.map((obj) => {
      const o = {};
      for (const p of clean) {
        const key = p.trim();
        o[key] = obj && typeof obj === "object" ? obj[key] ?? obj[capitalize(key)] : undefined;
      }
      return o;
    });
  });

  register("Where-Object", ["where", "?"], "Selects objects from a collection based on their property values.", ({ positional, named, pipeline }) => {
    const items = toArray(pipeline);
    const filter = positional[0] || param(named, ["filterscript"]);
    if (typeof filter === "string" && filter.includes("{")) {
      const body = filter.replace(/^\s*\{|\}\s*$/g, "");
      return items.filter((item) => evalPred(body, item));
    }
    const prop = positional[0] || param(named, ["property"]);
    const eq = param(named, ["eq"]);
    const ne = param(named, ["ne"]);
    const like = param(named, ["like"]);
    const match = param(named, ["match"]);
    const gt = param(named, ["gt"]);
    const lt = param(named, ["lt"]);
    return items.filter((item) => {
      const val = item && typeof item === "object" ? item[prop] ?? item[capitalize(String(prop))] : item;
      if (eq !== undefined) return String(val) === String(eq);
      if (ne !== undefined) return String(val) !== String(ne);
      if (like !== undefined) {
        const re = new RegExp("^" + String(like).replace(/\*/g, ".*") + "$", "i");
        return re.test(String(val));
      }
      if (match !== undefined) return new RegExp(String(match), "i").test(String(val));
      if (gt !== undefined) return Number(val) > Number(gt);
      if (lt !== undefined) return Number(val) < Number(lt);
      return Boolean(val);
    });
  });

  function evalPred(body, item) {
    const t = body.trim();
    const m = t.match(/^\$_\.([A-Za-z0-9_]+)\s*(-eq|-ne|-like|-match|-gt|-lt|-ge|-le)\s*(.+)$/i);
    if (!m) return Boolean(item);
    const val = item?.[m[1]] ?? item?.[capitalize(m[1])];
    const op = m[2].toLowerCase();
    let rhs = m[3].trim().replace(/^['"]|['"]$/g, "");
    switch (op) {
      case "-eq":
        return String(val) === rhs;
      case "-ne":
        return String(val) !== rhs;
      case "-like":
        return new RegExp("^" + rhs.replace(/\*/g, ".*") + "$", "i").test(String(val));
      case "-match":
        return new RegExp(rhs, "i").test(String(val));
      case "-gt":
        return Number(val) > Number(rhs);
      case "-lt":
        return Number(val) < Number(rhs);
      case "-ge":
        return Number(val) >= Number(rhs);
      case "-le":
        return Number(val) <= Number(rhs);
      default:
        return Boolean(val);
    }
  }

  register("ForEach-Object", ["foreach", "%"], "Performs an operation on each item.", async ({ positional, named, pipeline }) => {
    const items = toArray(pipeline);
    const member = param(named, ["membername"]);
    if (member) return items.map((i) => (i && typeof i === "object" ? i[member] : undefined));
    const script = positional[0] || param(named, ["process"]);
    if (!script) return items;
    const body = String(script).replace(/^\s*\{|\}\s*$/g, "");
    const out = [];
    for (const item of items) {
      if (body.includes("$_")) {
        if (/\$_\.ToUpper\(\)/i.test(body)) out.push(String(item).toUpperCase());
        else if (/\$_\.ToLower\(\)/i.test(body)) out.push(String(item).toLowerCase());
        else if (/\$_\.Length/i.test(body)) out.push(String(item).length);
        else if (/^\$_$/.test(body.trim())) out.push(item);
        else {
          const m = body.match(/^\$_\.([A-Za-z0-9_]+)$/);
          if (m) out.push(item?.[m[1]]);
          else out.push(item);
        }
      } else out.push(item);
    }
    return out;
  });

  register("Sort-Object", ["sort"], "Sorts objects by property values.", ({ positional, named, pipeline }) => {
    const items = [...toArray(pipeline)];
    const prop = positional[0] || param(named, ["property"]);
    const desc = flag(named, ["descending"]);
    items.sort((a, b) => {
      const av = prop && a && typeof a === "object" ? a[prop] ?? a[capitalize(String(prop))] : a;
      const bv = prop && b && typeof b === "object" ? b[prop] ?? b[capitalize(String(prop))] : b;
      if (av < bv) return desc ? 1 : -1;
      if (av > bv) return desc ? -1 : 1;
      return 0;
    });
    return items;
  });

  register("Group-Object", ["group"], "Groups objects that contain the same value.", ({ positional, named, pipeline }) => {
    const prop = positional[0] || param(named, ["property"]);
    const map = new Map();
    for (const item of toArray(pipeline)) {
      const key = prop && item && typeof item === "object" ? item[prop] ?? item[capitalize(String(prop))] : String(item);
      const k = String(key);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(item);
    }
    return [...map.entries()].map(([Name, Group]) => ({ Count: Group.length, Name, Group }));
  });

  register("Measure-Object", ["measure"], "Calculates the numeric properties of objects.", ({ named, pipeline }) => {
    const items = toArray(pipeline);
    const nums = items.map((x) => Number(x)).filter((n) => !Number.isNaN(n));
    const res = { Count: items.length };
    if (flag(named, ["sum"])) res.Sum = nums.reduce((a, b) => a + b, 0);
    if (flag(named, ["average"])) res.Average = nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
    if (flag(named, ["maximum"])) res.Maximum = nums.length ? Math.max(...nums) : null;
    if (flag(named, ["minimum"])) res.Minimum = nums.length ? Math.min(...nums) : null;
    return res;
  });

  register("Select-String", ["sls"], "Finds text in strings and files.", ({ positional, named, pipeline }) => {
    const pattern = positional[0] || param(named, ["pattern"]);
    const path = positional[1] || param(named, ["path"]);
    const re = new RegExp(String(pattern), flag(named, ["simplematch"]) ? undefined : "i");
    const rows = [];
    const scan = (text, src) => {
      String(text)
        .split(/\r?\n/)
        .forEach((line, i) => {
          if (re.test(line)) rows.push({ IgnoreCase: true, LineNumber: i + 1, Line: line, Filename: src });
        });
    };
    if (path) {
      const { node } = walk(path);
      if (node && node.type === "file") scan(node.content, path);
    } else {
      toArray(pipeline).forEach((x) => scan(typeof x === "object" ? JSON.stringify(x) : x, "InputStream"));
    }
    return rows;
  });

  register("Get-Unique", ["gu"], "Returns unique items.", ({ pipeline }) => {
    const seen = new Set();
    const out = [];
    for (const x of toArray(pipeline)) {
      const k = typeof x === "object" ? JSON.stringify(x) : String(x);
      if (!seen.has(k)) {
        seen.add(k);
        out.push(x);
      }
    }
    return out;
  });

  register("Compare-Object", ["compare", "diff"], "Compares two sets of objects.", ({ positional, named }) => {
    const a = toArray(positional[0] ?? param(named, ["referenceobject"]));
    const b = toArray(positional[1] ?? param(named, ["differenceobject"]));
    const sa = new Set(a.map((x) => JSON.stringify(x)));
    const sb = new Set(b.map((x) => JSON.stringify(x)));
    const out = [];
    for (const x of a) if (!sb.has(JSON.stringify(x))) out.push({ InputObject: x, SideIndicator: "<=" });
    for (const x of b) if (!sa.has(JSON.stringify(x))) out.push({ InputObject: x, SideIndicator: "=>" });
    return out;
  });

  register("Get-Member", ["gm"], "Gets the properties and methods of objects.", ({ pipeline }) => {
    const obj = unwrap(toArray(pipeline));
    if (obj == null) throw err("You must specify an object.");
    const type = Array.isArray(obj) ? "Object[]" : Object.prototype.toString.call(obj).slice(8, -1);
    const rows = [{ MemberType: "TypeName", Name: type, Definition: type }];
    if (typeof obj === "object") {
      for (const [k, v] of Object.entries(obj)) {
        rows.push({ MemberType: "NoteProperty", Name: k, Definition: `${typeof v} ${k}=${stringify(v)}` });
      }
    }
    return rows;
  });

  register("Format-Table", ["ft"], "Formats the output as a table.", ({ positional, named, pipeline }) => {
    formatValue(selectProps(pipeline, positional, named), "table");
    return { __silent: true };
  });
  register("Format-List", ["fl"], "Formats the output as a list of properties.", ({ positional, named, pipeline }) => {
    formatValue(selectProps(pipeline, positional, named), "list");
    return { __silent: true };
  });
  register("Format-Wide", ["fw"], "Formats objects as a wide table.", ({ pipeline }) => {
    const items = toArray(pipeline).map((x) => (x && x.Name) || stringify(x));
    print(items.join("    "));
    return { __silent: true };
  });

  function selectProps(pipeline, positional, named) {
    if (!positional.length && !named.property) return pipeline;
    return cmdlets["select-object"].fn({ positional, named, pipeline, ctx: {} });
  }

  register("ConvertTo-Json", [], "Converts an object to a JSON-formatted string.", ({ named, pipeline, positional }) => {
    const depth = Number(param(named, ["depth"], 4));
    const obj = pipeline !== undefined ? pipeline : coerce(positional[0]);
    return JSON.stringify(obj, null, flag(named, ["compress"]) ? 0 : 2);
  });

  register("ConvertFrom-Json", [], "Converts a JSON-formatted string to an object.", ({ pipeline, positional }) => {
    const text = String(pipeline ?? positional[0] ?? "");
    return JSON.parse(text);
  });

  register("ConvertTo-Csv", [], "Converts objects to CSV.", ({ pipeline }) => objectsToCsv(toArray(pipeline)));
  register("ConvertFrom-Csv", [], "Converts CSV to objects.", ({ pipeline, positional }) =>
    csvToObjects(String(pipeline ?? positional.join("\n")))
  );
  register("Export-Csv", [], "Converts objects to CSV and saves them.", ({ positional, named, pipeline }) => {
    const path = positional[0] || param(named, ["path"]);
    const csv = objectsToCsv(toArray(pipeline));
    const { parent, name } = ensureParent(path);
    parent.children[name] = { type: "file", content: csv, lastWriteTime: new Date().toISOString(), mode: "-a----" };
    persist();
  });
  register("Import-Csv", [], "Creates objects from CSV.", ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    const { node } = walk(path);
    if (!node || node.type !== "file") throw err(`Cannot find '${path}'.`);
    return csvToObjects(node.content || "");
  });

  function objectsToCsv(items) {
    if (!items.length) return "";
    const keys = [...new Set(items.flatMap((o) => (o && typeof o === "object" ? Object.keys(o) : ["Value"])))];
    const lines = [keys.join(",")];
    for (const o of items) {
      if (o && typeof o === "object") lines.push(keys.map((k) => csvEscape(o[k])).join(","));
      else lines.push(csvEscape(o));
    }
    return lines.join("\n");
  }
  function csvEscape(v) {
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }
  function csvToObjects(text) {
    const lines = text.split(/\r?\n/).filter((l) => l.length);
    if (!lines.length) return [];
    const headers = splitCsv(lines[0]);
    return lines.slice(1).map((line) => {
      const cols = splitCsv(line);
      const o = {};
      headers.forEach((h, i) => (o[h] = cols[i]));
      return o;
    });
  }
  function splitCsv(line) {
    const out = [];
    let cur = "";
    let q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) {
        if (c === '"' && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else if (c === '"') q = false;
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === ",") {
        out.push(cur);
        cur = "";
      } else cur += c;
    }
    out.push(cur);
    return out;
  }

  register("ConvertTo-Html", [], "Converts objects to HTML.", ({ pipeline }) => {
    const items = toArray(pipeline);
    const keys = [...new Set(items.flatMap((o) => (o && typeof o === "object" ? Object.keys(o) : [])))];
    let html = "<table><thead><tr>" + keys.map((k) => `<th>${k}</th>`).join("") + "</tr></thead><tbody>";
    for (const o of items) html += "<tr>" + keys.map((k) => `<td>${o?.[k] ?? ""}</td>`).join("") + "</tr>";
    return html + "</tbody></table>";
  });

  register("Invoke-WebRequest", ["iwr", "wget", "curl"], "Gets content from a web page on the Internet.", async ({ positional, named }) => {
    const url = positional[0] || param(named, ["uri", "url"]);
    if (!url) throw err("A Uri is required.");
    const method = String(param(named, ["method"], "GET")).toUpperCase();
    const body = param(named, ["body"]);
    const res = await fetch(url, { method, body: body != null ? String(body) : undefined });
    const text = await res.text();
    return {
      StatusCode: res.status,
      StatusDescription: res.statusText,
      Content: text,
      RawContentLength: text.length,
      Headers: Object.fromEntries(res.headers.entries()),
      BaseResponse: { RequestUri: url },
    };
  });

  register("Invoke-RestMethod", ["irm"], "Sends an HTTP or HTTPS request to a REST-ful web service.", async ({ positional, named }) => {
    const url = positional[0] || param(named, ["uri", "url"]);
    if (!url) throw err("A Uri is required.");
    const method = String(param(named, ["method"], "GET")).toUpperCase();
    const body = param(named, ["body"]);
    const headers = { Accept: "application/json" };
    if (body != null) headers["Content-Type"] = "application/json";
    const res = await fetch(url, { method, headers, body: body != null ? (typeof body === "string" ? body : JSON.stringify(body)) : undefined });
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  });

  register("Invoke-Expression", ["iex"], "Runs commands or expressions on the local computer.", ({ positional, pipeline }) => {
    const text = String(positional[0] ?? pipeline ?? "");
    return runScript(text);
  });

  register("Measure-Command", [], "Measures the time it takes to run script blocks.", async ({ positional }) => {
    const body = String(positional[0] || "").replace(/^\s*\{|\}\s*$/g, "");
    const t0 = performance.now();
    await runScript(body);
    const ms = performance.now() - t0;
    return { Days: 0, Hours: 0, Minutes: 0, Seconds: Math.floor(ms / 1000), Milliseconds: Math.round(ms % 1000), Ticks: Math.round(ms * 10000), TotalMilliseconds: ms };
  });

  register("Get-Variable", ["gv"], "Gets the variables in the current console.", ({ positional, named }) => {
    const name = String(positional[0] || param(named, ["name"], "") || "").toLowerCase();
    return Object.keys(vars)
      .filter((k) => !name || k.toLowerCase().includes(name.replace("*", "")))
      .sort()
      .map((Name) => ({ Name, Value: vars[Name] }));
  });

  register("Set-Variable", ["sv"], "Sets the value of a variable.", ({ positional, named }) => {
    const name = positional[0] || param(named, ["name"]);
    const value = positional[1] ?? param(named, ["value"]);
    vars[String(name)] = coerce(value);
    persist();
  });

  register("Remove-Variable", ["rv"], "Deletes a variable and its value.", ({ positional, named }) => {
    const name = positional[0] || param(named, ["name"]);
    delete vars[String(name)];
    persist();
  });

  register("Get-PSDrive", [], "Gets drives in the current session.", () => [
    { Name: "iOS", Used: null, Free: null, Provider: "FileSystem", Root: "/", Description: "Virtual iPhone filesystem" },
    { Name: "Env", Used: null, Free: null, Provider: "Environment", Root: "Env:", Description: "Environment" },
    { Name: "Variable", Used: null, Free: null, Provider: "Variable", Root: "Variable:", Description: "Variables" },
    { Name: "Alias", Used: null, Free: null, Provider: "Alias", Root: "Alias:", Description: "Aliases" },
    { Name: "Function", Used: null, Free: null, Provider: "Function", Root: "Function:", Description: "Functions" },
  ]);

  register("Get-PSProvider", [], "Gets information about the specified PowerShell provider.", () =>
    ["FileSystem", "Environment", "Variable", "Alias", "Function"].map((Name) => ({ Name, Drives: Name === "FileSystem" ? "iOS" : Name }))
  );

  register("Get-Module", ["gmo"], "Gets the modules that have been imported or that can be imported.", () => [
    { Name: "Microsoft.PowerShell.Core", Version: VERSION, ModuleType: "Manifest" },
    { Name: "Microsoft.PowerShell.Management", Version: VERSION, ModuleType: "Manifest" },
    { Name: "Microsoft.PowerShell.Utility", Version: VERSION, ModuleType: "Manifest" },
    { Name: "Microsoft.PowerShell.Host", Version: VERSION, ModuleType: "Manifest" },
    { Name: "PSReadLine", Version: "2.4.5", ModuleType: "Script" },
  ]);

  register("Get-Process", ["gps", "ps"], "Gets the processes that are running on the local computer.", () => {
    const mem = performance.memory;
    return [
      { Id: 1, ProcessName: "SpringBoard", CPU: 0.1, WorkingSet: null },
      { Id: 7, ProcessName: "pwsh", CPU: 0.4, WorkingSet: mem ? mem.usedJSHeapSize : null },
      { Id: 77, ProcessName: "Safari Web Content", CPU: 0.2, WorkingSet: mem ? mem.totalJSHeapSize : null },
    ];
  });

  register("Stop-Process", ["kill", "spps"], "Stops one or more running processes.", ({ named }) => {
    print(`Stop-Process: iOS does not allow killing system processes from a web host. Requested: ${param(named, ["name", "id"]) || ""}`, "warn");
  });

  register("Get-Service", ["gsv"], "Gets the services on a local or remote computer.", () => [
    { Status: "Running", Name: "pwsh-host", DisplayName: "PowerShell iOS Host" },
    { Status: "Running", Name: "localstorage", DisplayName: "Filesystem Persistence" },
    { Status: "Stopped", Name: "WinRM", DisplayName: "Windows Remote Management (not available on iOS)" },
  ]);

  register("Get-Clipboard", [], "Gets the current clipboard contents.", async () => {
    try {
      return await navigator.clipboard.readText();
    } catch {
      throw err("Clipboard permission denied. Use the Paste key or grant clipboard access.");
    }
  });

  register("Set-Clipboard", [], "Sets the current clipboard contents.", async ({ positional, pipeline }) => {
    const text = String(positional[0] ?? (pipeline != null ? stringify(pipeline) : ""));
    await navigator.clipboard.writeText(text);
  });

  register("Get-FileHash", [], "Computes the hash value for a file.", async ({ positional, named }) => {
    const path = positional[0] || param(named, ["path"]);
    const algo = String(param(named, ["algorithm"], "SHA256")).toUpperCase();
    const { node } = walk(path);
    if (!node || node.type !== "file") throw err(`Cannot find file '${path}'.`);
    const data = new TextEncoder().encode(node.content || "");
    const name = algo === "SHA1" ? "SHA-1" : algo === "SHA256" ? "SHA-256" : algo === "SHA384" ? "SHA-384" : algo === "SHA512" ? "SHA-512" : "SHA-256";
    const buf = await crypto.subtle.digest(name, data);
    const hash = [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
    return { Algorithm: algo, Hash: hash, Path: normPath(path) };
  });

  register("WhoAmI", ["whoami"], "Gets the current user.", () => USER);

  register("Get-ComputerInfo", [], "Gets a snapshot of the environment.", () => ({
    OsName: /iPhone/.test(navigator.userAgent) ? "iOS / iPhone" : /iPad/.test(navigator.userAgent) ? "iPadOS" : navigator.platform,
    CsName: "iPhone",
    OsVersion: navigator.userAgent,
    WindowsProductName: "n/a",
    TimeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    Language: navigator.language,
    HardwareConcurrency: navigator.hardwareConcurrency || 1,
    DeviceMemoryGB: navigator.deviceMemory || null,
    OnLine: navigator.onLine,
    Vendor: navigator.vendor,
  }));

  register("Get-Battery", [], "Gets battery status from the device.", async () => {
    if (!navigator.getBattery) return { Supported: false, Note: "Battery Status API not available on this iOS version." };
    const b = await navigator.getBattery();
    return { Charging: b.charging, Level: Math.round(b.level * 100) + "%", ChargingTime: b.chargingTime, DischargingTime: b.dischargingTime };
  });

  register("Get-Culture", [], "Gets the current culture.", () => ({
    Name: navigator.language,
    DisplayName: navigator.language,
    DateTimeFormat: Intl.DateTimeFormat().resolvedOptions(),
  }));

  register("Get-UICulture", [], "Gets the current UI culture.", () => ({ Name: navigator.language }));

  register("Get-Error", [], "Gets and displays error objects.", () => vars.Error || []);

  register("Set-Theme", [], "Sets the terminal theme: Classic, Cascade, or Light.", ({ positional }) => {
    const t = String(positional[0] || "classic").toLowerCase();
    if (!themes.includes(t)) throw err("Theme must be Classic, Cascade, or Light.");
    theme = t;
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(STORE_THEME, theme);
    const color = theme === "classic" ? "#012456" : theme === "cascade" ? "#0c0c0c" : "#f3f3f3";
    document.querySelector('meta[name="theme-color"]').setAttribute("content", color);
    print(`Theme set to ${t}`, "ok");
    return { __silent: true };
  });

  register("Connect-PSSession", ["Enter-PSSession"], "Explains how to attach this iPhone to a real Microsoft pwsh process.", () =>
    [
      "REAL MICROSOFT POWERSHELL ON IPHONE",
      "",
      "Apple does not allow a native Microsoft pwsh runtime inside a third-party iOS app.",
      "Official PowerShell 7.6 installs on Windows, macOS, and Linux only:",
      "https://learn.microsoft.com/en-us/powershell/scripting/install/install-powershell-on-macos",
      "",
      "To get every Microsoft capability (AD, Graph, Az, CIM, WinRM, real processes):",
      "  1. Install PowerShell 7.6 on a Mac mini, PC, or VPS.",
      "  2. Enable SSH (macOS: System Settings → Remote Login).",
      "  3. On this iPhone install Termius, Blink Shell, Prompt 3, or rootshell.",
      "  4. SSH in and run:  pwsh",
      "",
      "This host already gives you the language, pipeline, filesystem, JSON/CSV,",
      "web cmdlets, history, aliases, and formatting offline on the phone.",
    ].join("\n")
  );

  register("Update-Help", [], "Downloads and installs help files.", () => {
    print("Help content is bundled with pwsh-ios. No download required.", "dim");
    return { __silent: true };
  });

  register("Get-PSReadLineOption", [], "Gets the PSReadLine options.", () => ({
    EditMode: "Windows",
    HistoryNoDuplicates: true,
    PredictionSource: "History",
    Colors: { Command: "Yellow", Parameter: "Cyan", String: "DarkCyan" },
  }));

  register("Show-Banner", [], "Shows the PowerShell startup banner.", () => {
    showBanner();
    return { __silent: true };
  });

  /* ranges like 1..5 */
  const origResolve = resolveCommand;
  function expandLeadingRange(text) {
    return text.replace(/(^|[^\w])(\d+)\.\.(\d+)/g, (_, p, a, b) => {
      const start = Number(a);
      const end = Number(b);
      const arr = [];
      const step = start <= end ? 1 : -1;
      for (let n = start; step > 0 ? n <= end : n >= end; n += step) arr.push(n);
      return p + arr.join(",");
    });
  }

  /* ---------------- UI ---------------- */

  function showBanner() {
    print(`PowerShell ${VERSION}`, "banner");
    print(`Copyright (c) Microsoft Corporation.`, "dim");
    print(``);
    print(`https://aka.ms/powershell`, "accent");
    print(`Type 'help' to get help.`, "dim");
    print(``);
    print(`Host: pwsh-ios  |  Edition: ${EDITION}  |  Compatible with PowerShell 7.6`, "dim");
    print(`Official pwsh is not available on iOS. Type Connect-PSSession for the real runtime.`, "warn");
    print(``);
  }

  function complete() {
    const val = $cmd.value;
    const start = val.slice(0, $cmd.selectionStart);
    const m = start.match(/([^\s|;]+)$/);
    const prefix = m ? m[1] : "";
    if (!prefix) return;
    const names = [
      ...Object.values(cmdlets).map((c) => c.name),
      ...Object.keys(aliases),
      ...Object.keys(functions),
      ...Object.keys(vars).map((v) => "$" + v),
    ];
    if (prefix.startsWith("./") || prefix.startsWith("/") || prefix.startsWith("~") || prefix.includes("\\") || prefix.startsWith(".")) {
      const npath = normPath(prefix);
      const isDirHint = /[\\/]$/.test(prefix);
      const parentPath = isDirHint ? npath : npath.split("/").slice(0, -1).join("/") || "/";
      const leaf = isDirHint ? "" : npath.split("/").pop();
      const { node } = walk(parentPath);
      if (node && node.type === "dir") {
        const hits = Object.keys(node.children).filter((n) => n.toLowerCase().startsWith(leaf.toLowerCase()));
        if (hits.length === 1) {
          const full = (parentPath.replace(/\/$/, "") + "/" + hits[0]).replace(/\/+/g, "/");
          $cmd.value = val.slice(0, $cmd.selectionStart - prefix.length) + full + val.slice($cmd.selectionStart);
          return;
        }
        if (hits.length) print(hits.join("    "), "dim");
      }
      return;
    }
    const hits = names.filter((n) => n.toLowerCase().startsWith(prefix.toLowerCase()));
    if (hits.length === 1) {
      $cmd.value = val.slice(0, $cmd.selectionStart - prefix.length) + hits[0] + val.slice($cmd.selectionStart);
    } else if (hits.length) {
      print(hits.slice(0, 40).join("    ") + (hits.length > 40 ? " ..." : ""), "dim");
    }
  }

  async function submit() {
    const line = $cmd.value.replace(/\s+$/, "");
    $cmd.value = "";
    autosize();
    writePromptEcho(line);
    if (!line) return;
    history.push(line);
    if (history.length > 400) history = history.slice(-400);
    histIdx = history.length;
    persist();
    abortFlag = false;
    running = true;
    try {
      let text = line.trim();
      if (/^\d+\.\.\d+(\s|\||$)/.test(text)) text = expandLeadingRange(text);
      const result = await runScript(text);
      formatValue(result);
    } catch (e) {
      print(e && e.message ? e.message : String(e), "err");
      vars.Error = toArray(vars.Error).concat([{ Exception: String(e.message || e), CategoryInfo: "NotSpecified" }]).slice(-20);
    } finally {
      running = false;
      $screen.scrollTop = $screen.scrollHeight;
      $cmd.focus();
    }
  }

  function autosize() {
    $cmd.style.height = "auto";
    $cmd.style.height = Math.min($cmd.scrollHeight, 120) + "px";
  }

  function insertText(t) {
    const start = $cmd.selectionStart;
    const end = $cmd.selectionEnd;
    $cmd.value = $cmd.value.slice(0, start) + t + $cmd.value.slice(end);
    const pos = start + t.length;
    $cmd.setSelectionRange(pos, pos);
    autosize();
    $cmd.focus();
  }

  $cmd.addEventListener("input", autosize);
  $cmd.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    } else if (e.key === "Tab") {
      e.preventDefault();
      complete();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (histIdx === history.length) draft = $cmd.value;
      if (histIdx > 0) {
        histIdx--;
        $cmd.value = history[histIdx] || "";
        autosize();
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (histIdx < history.length) {
        histIdx++;
        $cmd.value = histIdx === history.length ? draft : history[histIdx] || "";
        autosize();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c") {
      if (running) {
        abortFlag = true;
        print("^C", "warn");
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "l") {
      e.preventDefault();
      $screen.innerHTML = "";
    }
  });

  $keys.addEventListener("click", async (e) => {
    const btn = e.target.closest("button");
    if (!btn) return;
    if (btn.dataset.k === "Ctrl") {
      ctrlOn = !ctrlOn;
      btn.setAttribute("data-on", ctrlOn ? "1" : "0");
      return;
    }
    if (btn.dataset.k === "Tab") return complete();
    if (btn.dataset.k === "Enter") {
      if (ctrlOn) {
        insertText("\n");
        ctrlOn = false;
        document.getElementById("btn-ctrl").setAttribute("data-on", "0");
        return;
      }
      return submit();
    }
    if (btn.dataset.k === "Esc") {
      $cmd.value = "";
      autosize();
      return;
    }
    if (btn.dataset.k === "ArrowUp" || btn.dataset.k === "ArrowDown") {
      $cmd.dispatchEvent(new KeyboardEvent("keydown", { key: btn.dataset.k, bubbles: true }));
      return;
    }
    if (btn.dataset.k === "ArrowLeft" || btn.dataset.k === "ArrowRight") {
      const delta = btn.dataset.k === "ArrowLeft" ? -1 : 1;
      const pos = Math.max(0, Math.min($cmd.value.length, $cmd.selectionStart + delta));
      $cmd.setSelectionRange(pos, pos);
      $cmd.focus();
      return;
    }
    if (btn.dataset.insert) {
      if (ctrlOn && btn.dataset.insert === "c") {
        abortFlag = true;
        print("^C", "warn");
        ctrlOn = false;
        document.getElementById("btn-ctrl").setAttribute("data-on", "0");
        return;
      }
      insertText(btn.dataset.insert);
      return;
    }
    if (btn.dataset.act === "paste") {
      try {
        insertText(await navigator.clipboard.readText());
      } catch {
        print("Clipboard blocked. Long-press the input and choose Paste.", "warn");
      }
      return;
    }
    if (btn.dataset.act === "cls") {
      $screen.innerHTML = "";
    }
  });

  document.getElementById("btn-theme").addEventListener("click", () => {
    const i = (themes.indexOf(theme) + 1) % themes.length;
    runScript(`Set-Theme ${themes[i]}`);
  });
  document.getElementById("btn-help").addEventListener("click", () => runScript("Get-Help").then(formatValue));

  if (window.visualViewport) {
    const vv = window.visualViewport;
    const sync = () => {
      const hidden = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      document.documentElement.style.setProperty("--kb", hidden ? "0px" : "0px");
    };
    vv.addEventListener("resize", sync);
    vv.addEventListener("scroll", sync);
    sync();
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }

  const standalone = window.navigator.standalone === true || window.matchMedia("(display-mode: standalone)").matches;
  if (!standalone && /iPhone|iPad|iPod/.test(navigator.userAgent)) {
    $install.style.display = "block";
  }
  document.getElementById("install-ok").addEventListener("click", () => {
    $install.style.display = "none";
    sessionStorage.setItem("pwsh.install.dismissed", "1");
  });
  if (sessionStorage.getItem("pwsh.install.dismissed")) $install.style.display = "none";

  $hostmeta.textContent = /iPhone/.test(navigator.userAgent) ? "iPhone" : "pwsh-ios";
  refreshPrompt();
  showBanner();
  $cmd.focus();

  window.pwsh = { runScript, vars, cwd: () => cwd };
})();
