# PowerShell 7 for iPhone

A PowerShell 7.6-compatible terminal you can install on an iPhone Home Screen.

Microsoft does **not** ship official `pwsh` for iOS. Official installers cover Windows, macOS, and Linux only:

https://learn.microsoft.com/en-us/powershell/scripting/install/install-powershell-on-macos?view=powershell-7.6

This host implements the PowerShell *language surface* on the phone: prompt, aliases, pipelines, providers, filesystem, JSON/CSV, web cmdlets, history, tab completion, and formatting. For Active Directory, Azure, CIM, WinRM, and real OS processes, SSH into a machine that runs Microsoft PowerShell 7.6 and type `pwsh`.

## Install on iPhone

1. Open the deployed site in Safari (not Chrome).
2. Tap the Share button.
3. Tap **Add to Home Screen**.
4. Open **pwsh**. It launches full-screen like a native app and works offline.

## Try

```powershell
Get-Help
Get-Command
Get-ChildItem
Set-Location /Users/Jendry/Documents
Get-Content notes.txt
1..10 | Measure-Object -Sum
Get-Date -Format yyyy-MM-dd
New-Guid
Invoke-RestMethod https://httpbin.org/json
Set-Theme Cascade
Connect-PSSession
```

## Themes

`Set-Theme Classic` · `Set-Theme Cascade` · `Set-Theme Light`
